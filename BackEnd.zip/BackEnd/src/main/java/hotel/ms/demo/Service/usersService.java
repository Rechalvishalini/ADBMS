package hotel.ms.demo.Service;

import java.util.List;

import hotel.ms.demo.Domain.users;

public interface usersService {
    public List<users> getAllUsers();
}
